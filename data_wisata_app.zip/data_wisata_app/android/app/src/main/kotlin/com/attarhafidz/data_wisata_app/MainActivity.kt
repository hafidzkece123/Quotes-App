package com.attarhafidz.data_wisata_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
