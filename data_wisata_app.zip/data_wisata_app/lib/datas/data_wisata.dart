import 'package:flutter/material.dart';

class DataWisata {
  final String title;
  final String subTitle;
  final String image;
  final MaterialColor materialColor;

  DataWisata({this.title, this.subTitle, this.image, this.materialColor});

  List<DataWisata> createDataWisata(){
    List _dataWisata = List<DataWisata>();
    return _dataWisata
      ..add(DataWisata(
          title: "Museum Angkut",
          subTitle: "Museum Angkut merupakan museum transportasi dan tempat wisata modern yang terletak di Kota Batu, Jawa Timur, sekitar 20 km dari Kota Malang. Museum ini terletak di kawasan seluas 3,8 hektar di lereng Gunung Panderman dan memiliki lebih dari 300 koleksi jenis angkutan tradisional hingga modern. Museum ini terbagi dalam beberapa zona yang didekorasi dengan setting landscape model bangunan dari benua Asia, Eropa hingga Amerika. Di Zona Sunda Kelapa dan Batavia yang merupakan Replika Pelabuhan Sunda Kelapa, dihiasi oleh beberapa alat transportasi kuno seperti becak dan miniatur kapal. Zona Eropa juga di setting seakan-akan berada di jalanan kota-kota di Prancis dengan mobil-mobil kuno eropa.",
          image:
          "https://www.mldspot.com/sites/default/files/styles/wide_big/public/field/image/Review%20Museum%20Angkut%20Malang%20Tiket.jpg?itok=i30XKMP1",
          materialColor: Colors.blue))
      ..add(DataWisata(
          title: "Kota Tua",
          subTitle: "Tahun 1526, Fatahillah, dikirim oleh Kesultanan Demak, menyerang pelabuhan Sunda Kelapa di kerajaan Hindu Pajajaran, kemudian dinamai Jayakarta. Kota ini hanya seluas 15 hektare dan memiliki tata kota pelabuhan tradisional Jawa. Tahun 1619, VOC menghancurkan Jayakarta di bawah komando Jan Pieterszoon Coen. Satu tahun kemudian, VOC membangun kota baru bernama Batavia untuk menghormati Batavieren, leluhur bangsa Belanda. Kota ini terpusat di sekitar tepi timur Sungai Ciliwung, saat ini Lapangan Fatahillah.",
          image:
          "https://img.alinea.id/img/content/2019/06/06/38959/jam-kunjungan-museum-museum-di-kota-tua-jakarta-diperpanjang-NpjK8GD2ce.jpg",
          materialColor: Colors.red))
      ..add(DataWisata(
          title: "Museum Peta",
          subTitle: "Museum Pembela Tanah Air (Museum PETA) merupakan museum yang didirikan untuk memberikan penghargaan kepada mantan tentara PETA atas kontribusinya dalam pendirian bangsa dan negara. Selain itu, museum yang terletak di Bogor ini juga didirikan untuk memberi gambaran perjuangan kemerdekaan Indonesia dan persiapan dalam mengisi kemerdekaan ",
          image:
          "https://awsimages.detik.net.id/content/2017/12/27/1025/img_20171227175919_5a437d075223e.JPG",
          materialColor: Colors.green))
      ..add(DataWisata(
          title: "Jungle Land",
          subTitle: "Jungle adalah tempat wisata dan rekreasi para wisatawan jungle lan d berada di kota bogor di situ kita dapat bermain wahan DLL",
          image:
          "https://awsimages.detik.net.id/visual/2020/09/25/dokthe-jungle-land.png?w=650",
          materialColor: Colors.yellow))
      ..add(DataWisata(
          title: "Museum Tanah",
          subTitle: "Museum ini terletak di ujung utara danau terbesar keempat Norwegia , Randsfjorden , dan dekat cagar alam Dokka Delta. Museum ini didirikan pada tahun 1927. Lands Museum kini menjadi bagian dari Randsfjordmuseene bersama Hadeland Folkemuseum di Tingelstad di Gran , Hadeland Bergverksmuseum di Lunner dan Kittilbu Utmarksmuseum di Gausdal.",
          image:
          "https://kelanaku.com/wp-content/uploads/2018/11/Museum-Tanah-Bogor.jpg",
          materialColor: Colors.purple))
      ..add(DataWisata(
          title: "Monas",
          subTitle: "Monumen Nasional atau yang populer disingkat dengan Monas atau Tugu Monas adalah monumen peringatan setinggi 132 meter (433 kaki) yang didirikan untuk mengenang perlawanan dan perjuangan rakyat Indonesia untuk merebut kemerdekaan dari pemerintahan kolonial Hindia Belanda. Pembangunan monumen ini dimulai pada tanggal 17 Agustus 1961 di bawah perintah presiden Sukarno dan dibuka untuk umum pada tanggal 12 Juli 1975. Tugu ini dimahkotai lidah api yang dilapisi lembaran emas yang melambangkan semangat perjuangan yang menyala-nyala. Monumen Nasional terletak tepat di tengah Lapangan Medan Merdeka, Jakarta Pusat.",
          image:
          "https://mmc.tirto.id/image/2018/07/28/ilustrasi-monas-2_ratio-16x9.jpg",
          materialColor: Colors.pink))
      ..add(DataWisata(
          title: "Taman Safari",
          subTitle: "Taman Safari Indonesia adalah tempat wisata keluarga berwawasan lingkungan yang berorientasi pada habitat satwa di alam bebas. Taman Safari Indonesia terletak di Desa Cibeureum Kecamatan Cisarua, Kabupaten Bogor, Jawa Barat atau yang lebih dikenal dengan kawasan Puncak. Taman ini berfungsi menjadi penyangga Taman Nasional Gunung Gede Pangrango di ketinggian 900-1800 m di atas permukaan laut, serta mempunyai suhu rata-rata 16 - 24 derajat Celsius.[1]",
          image:
          "https://akcdn.detik.net.id/visual/2020/06/10/kondisi-satwa-tsi-bogor_169.jpeg?w=650",
          materialColor: Colors.orange))
      ..add(DataWisata(
          title: "Taman Mini",
          subTitle: "Taman Mini Indonesia Indah (TMII) merupakan suatu kawasan taman wisata bertema budaya Indonesia di Jakarta Timur. Area seluas kurang lebih 150 hektare[1] atau 1,5 kilometer persegi ini terletak pada koordinat 6°18′6.8″LS,106°53′47.2″BT. Taman ini merupakan rangkuman kebudayaan bangsa Indonesia, yang mencakup berbagai aspek kehidupan sehari-hari masyarakat 26 provinsi Indonesia (pada tahun 1975) yang ditampilkan dalam anjungan daerah berarsitektur tradisional, serta menampilkan aneka busana, tarian, dan tradisi daerah. Di samping itu, di tengah-tengah TMII terdapat sebuah danau yang menggambarkan miniatur kepulauan Indonesia di tengahnya, kereta gantung, berbagai museum, dan Teater IMAX Keong Mas dan Teater Tanah Airku), berbagai sarana rekreasi ini menjadikan TMIII sebagai salah satu kawasan wisata terkemuka di ibu kota.[2]",
          image:
          "https://anekatempatwisata.com/wp-content/uploads/2014/08/Teater-IMAX-Keong-Mas.jpg",
          materialColor: Colors.brown))
      ..add(DataWisata(
          title: "Museum Mobil",
          subTitle: "Tahun 2012 Classic Car Museum Cikunir didirikan oleh bapak Ermin Nasution pecinta mobil antik. Salah satu bentuk kecintaan Pak Ermin terhadap mobil klasik terlihat dari upayanya mendirikan Museum ini. Terdapat puluhan koleksi mobil klasik mulai dari era pra-Perang Dunia hingga Pasca-Perang Dunia II.",
          image:
          "https://i.misteraladin.com/blog/2018/10/29135905/hauwke2.jpg",
          materialColor: Colors.lightGreen))
      ..add(DataWisata(
          title: "Museum Keramik",
          subTitle: "Museum Seni Rupa dan Keramik terletak di Jalan Pos Kota No 2, Kotamadya Jakarta Barat, Provinsi DKI Jakarta, Indonesia. Museum yang tepatnya berada di seberang Museum Sejarah Jakarta itu memajang keramik lokal dari berbagai daerah di Tanah Air, dari era Kerajaan Majapahit abad ke-14, dan dari berbagai negara di dunia.",
          image:
          "https://upload.wikimedia.org/wikipedia/commons/9/98/Museum_Seni_Rupa_dan_Keramik_Main_images10.png",
          materialColor: Colors.lightBlue));
  }
}